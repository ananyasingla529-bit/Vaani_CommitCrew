import type { FlaggedMessage, ConnectedSource, OverviewStats, SystemSettings } from '../types';

export const INITIAL_MOCK_SOURCES: ConnectedSource[] = [
  {
    id: 'src_tg_01',
    platform: 'telegram',
    channel_id: '-1001839201948',
    channel_name: 'Delhi University Student Forum',
    url: 'https://t.me/du_student_council_chat',
    status: 'connected',
    flags_count: 18,
    created_at: '2026-10-15T09:30:00Z',
  },
  {
    id: 'src_tg_02',
    platform: 'telegram',
    channel_id: '-1001994827104',
    channel_name: 'OpenSource Bharat Community',
    url: 'https://t.me/opensource_bharat_official',
    status: 'connected',
    flags_count: 7,
    created_at: '2026-10-18T14:15:00Z',
  },
  {
    id: 'src_dc_01',
    platform: 'discord',
    channel_id: '928374615243109283',
    channel_name: 'DevIndia #general-chat',
    url: 'https://discord.gg/devindia-tech',
    status: 'connected',
    flags_count: 14,
    created_at: '2026-10-12T11:00:00Z',
  },
  {
    id: 'src_dc_02',
    platform: 'discord',
    channel_id: '883719204857291048',
    channel_name: 'Campus Tech Hub #voice-text',
    url: 'https://discord.gg/campustech-india',
    status: 'connected',
    flags_count: 8,
    created_at: '2026-10-20T16:45:00Z',
  },
  {
    id: 'src_yt_01',
    platform: 'youtube',
    channel_id: 'UCX984720194837261',
    channel_name: 'Campus Spotlight & Debates',
    url: 'https://youtube.com/@campus_spotlight_debates',
    status: 'connected',
    flags_count: 9,
    created_at: '2026-10-10T08:00:00Z',
  },
  {
    id: 'src_yt_02',
    platform: 'youtube',
    channel_id: 'UCZ472819384729104',
    channel_name: 'TechBytes Hindi Tutorials',
    url: 'https://youtube.com/@techbytes_hindi',
    status: 'permission_missing',
    flags_count: 2,
    created_at: '2026-10-25T13:20:00Z',
    permission_hint: 'Re-authorize Google OAuth with commentThreads.manage permissions to enable automated comment moderation.',
  },
];

export const MOCK_MESSAGES: FlaggedMessage[] = [
  // Item 1: High severity Threat targeting @priya_sharma_du
  {
    id: 'msg_001',
    platform: 'telegram',
    source_id: 'src_tg_01',
    channel_name: 'Delhi University Student Forum',
    sender_id: 'tg_user_9921',
    sender_name: 'Karan Malhotra',
    text: '@priya_sharma_du college aake dikha kal, tera vo haal karunga ki hospital me admit hona padega. m@r daloonga tujhe.',
    normalized_text: '@priya_sharma_du college aakar dikha kal, tera wo haal karunga ki hospital mein admit hona padega. maar daloonga tujhe.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-31T14:48:00Z',
    context: [
      'Priya Sharma: Elections ke rules sabke liye equal hone chahiye, hum application submit kar chuke hain.',
      'Karan Malhotra: Tu hoti kon hai rules decide karne wali? Zyada shani mat ban.',
      'Aman Gupta: Bro relax, let the election committee decide peaceful raho.'
    ],
    category: 'Threat',
    severity: 'high',
    explanation: 'Explicit physical assault threat and death threat ("hospital me admit hona padega", "m@r daloonga tujhe") directed at student representative.',
    target_user: '@priya_sharma_du',
    status: 'new'
  },
  // Item 2: High severity Harassment/Insult targeting @priya_sharma_du
  {
    id: 'msg_002',
    platform: 'telegram',
    source_id: 'src_tg_01',
    channel_name: 'Delhi University Student Forum',
    sender_id: 'tg_user_8841',
    sender_name: 'Rahul_DU_07',
    text: 'priya jaise chapri aur k*tti ladkiyo ko representation kisne diya? sharam bech khai hai tune @priya_sharma_du nikal yaha se.',
    normalized_text: 'priya jaise chapri aur kutti ladkiyon ko representation kisne diya? sharam bech khai hai tune @priya_sharma_du nikal yahan se.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-31T14:51:30Z',
    context: [
      'Karan Malhotra: Tu hoti kon hai rules decide karne wali? Zyada shani mat ban.',
      'Aman Gupta: Bro relax, let the election committee decide peaceful raho.',
      'Priya Sharma: Hum democratic process follow kar rahe hain, abuses report honge.'
    ],
    category: 'Harassment',
    severity: 'high',
    explanation: 'Targeted misogynistic harassment and abusive slurs ("k*tti", "sharam bech khai") in active pile-on campaign.',
    target_user: '@priya_sharma_du',
    status: 'new'
  },
  // Item 3: Repeat target @priya_sharma_du on Discord
  {
    id: 'msg_003',
    platform: 'discord',
    source_id: 'src_dc_02',
    channel_name: 'Campus Tech Hub #voice-text',
    sender_id: 'dc_user_7719',
    sender_name: 'ViperSquad',
    text: 'Guys spam @priya_sharma_du DMs and report her profile. let her cry off this server and withdraw her nomination.',
    normalized_text: 'Guys spam @priya_sharma_du DMs and report her profile. Let her cry off this server and withdraw her nomination.',
    language: 'English',
    timestamp: '2026-10-31T14:55:12Z',
    context: [
      'Rohan: Council candidates are doing an AMA in voice channel tonight.',
      'ViperSquad: Nobody wants to hear from her council group.',
      'Simran: Please keep the server guidelines in mind, no brigading.'
    ],
    category: 'Harassment',
    severity: 'high',
    explanation: 'Coordinated brigading and targeted harassment campaign soliciting DM spam to intimidate nomination candidate.',
    target_user: '@priya_sharma_du',
    status: 'new'
  },
  // Item 4: Repeat target @priya_sharma_du on YouTube
  {
    id: 'msg_004',
    platform: 'youtube',
    source_id: 'src_yt_01',
    channel_name: 'Campus Spotlight & Debates',
    sender_id: 'yt_user_3320',
    sender_name: 'DesiRider99',
    text: 'iss aurat ki aukaat dekho debate me bolne ki. 2 paise ki k*meeni @priya_sharma_du jhoothi b@stard.',
    normalized_text: 'iss aurat ki aukaat dekho debate mein bolne ki. 2 paise ki kameeni @priya_sharma_du jhoothi bastard.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-31T13:22:00Z',
    context: [
      'Campus Spotlight: Watch our candidate debate recorded live at North Campus.',
      'StudentVoice: Priya made some solid points about lab funding.',
      'Ankit: The open floor round was heated.'
    ],
    category: 'Insult/Bullying',
    severity: 'high',
    explanation: 'Severe abusive gender-biased verbal abuse ("aukaat", "k*meeni", "b@stard") targeting student council candidate.',
    target_user: '@priya_sharma_du',
    status: 'new'
  },
  // Item 5: High severity Threat targeting @rohit_tech_lead
  {
    id: 'msg_005',
    platform: 'discord',
    source_id: 'src_dc_01',
    channel_name: 'DevIndia #general-chat',
    sender_id: 'dc_user_4491',
    sender_name: 'NullPointerX',
    text: '@rohit_tech_lead tune mera PR close kiya na? I have your Bangalore address. office ke bahar tera sir phod dunga b@stard.',
    normalized_text: '@rohit_tech_lead tune mera PR close kiya na? I have your Bangalore address. office ke bahar tera sir phod doonga bastard.',
    language: 'Hinglish',
    timestamp: '2026-10-31T14:30:00Z',
    context: [
      'Rohit V: Closing PR #342 due to malicious code injection and security policy failure.',
      'NullPointerX: What malicious? You reject all external contributions intentionally!',
      'Rohit V: The commit contained plain-text webhook scrapers, see review comments.'
    ],
    category: 'Threat',
    severity: 'high',
    explanation: 'Doxxing threat coupled with explicit physical violence threat ("I have your Bangalore address", "sir phod dunga").',
    target_user: '@rohit_tech_lead',
    status: 'new'
  },
  // Item 6: Harassment targeting @rohit_tech_lead on Telegram
  {
    id: 'msg_006',
    platform: 'telegram',
    source_id: 'src_tg_02',
    channel_name: 'OpenSource Bharat Community',
    sender_id: 'tg_user_2209',
    sender_name: 'CodeRebel',
    text: '@rohit_tech_lead tu fraud hai, tera career khatam kar dunga fake reviews post karke. kuttey jaise bhagta phirega.',
    normalized_text: '@rohit_tech_lead tu fraud hai, tera career khatam kar doonga fake reviews post karke. kutte jaise bhagta phirega.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-31T12:15:00Z',
    context: [
      'DevIndia Bot: New discussion opened in core repository.',
      'Rohit V: Reminder: Please follow the code of conduct during architecture reviews.',
      'Vikram: Let us keep technical discussions professional please.'
    ],
    category: 'Harassment',
    severity: 'high',
    explanation: 'Professional intimidation and defamation threat with dehumanizing abuse ("kuttey jaise bhagta phirega").',
    target_user: '@rohit_tech_lead',
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-31T13:00:00Z'
  },
  // Item 7: Threat & Insult targeting @arjun_v98
  {
    id: 'msg_007',
    platform: 'youtube',
    source_id: 'src_yt_01',
    channel_name: 'Campus Spotlight & Debates',
    sender_id: 'yt_user_6612',
    sender_name: 'GamerX_Punjab',
    text: '@arjun_v98 tu mil mainu Chandigarh ch, teri lattan bhan dunga kanj*r. bada chaud banna phirda.',
    normalized_text: '@arjun_v98 tu mil mainu Chandigarh ch, teri lattan bhan doonga kanjar. bada chaud banna phirda.',
    language: 'Punjabi (Romanized)',
    timestamp: '2026-10-31T11:42:00Z',
    context: [
      'Arjun Verma: Tournament highlights are out, good game everyone!',
      'GamerX_Punjab: Cheater detected, lag switch use kitta si tune.',
      'Arjun Verma: Official referee checked the stream logs bro, clean match.'
    ],
    category: 'Threat',
    severity: 'high',
    explanation: 'Direct physical violence threat in Romanized Punjabi ("lattan bhan dunga" - will break your legs) with abusive slur ("kanj*r").',
    target_user: '@arjun_v98',
    status: 'new'
  },
  // Item 8: False Positive 1 (Compliment with fire metaphor)
  {
    id: 'msg_008',
    platform: 'youtube',
    source_id: 'src_yt_01',
    channel_name: 'Campus Spotlight & Debates',
    sender_id: 'yt_user_1190',
    sender_name: 'Sahil Music Lover',
    text: 'bhai tu to aag laga di stage pe! kya performance thi maza aa gaya yaar bilkul faad diya!',
    normalized_text: 'bhai tu toh aag laga di stage pe! kya performance thi maza aa gaya yaar bilkul faad diya!',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-31T10:15:00Z',
    context: [
      'Campus Cultural Fest: Solo singing finals highlight clip.',
      'Ritu: Best performance of the evening!',
      'Deepak: Audience was completely energized.'
    ],
    category: 'Insult/Bullying',
    severity: 'low',
    explanation: 'FALSE POSITIVE: Colloquial praise expressions "aag laga di" (set stage on fire) and "faad diya" used metaphorically for high artistic praise.',
    target_user: null,
    status: 'dismissed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-31T10:30:00Z'
  },
  // Item 9: False Positive 2 (English slang 'dead')
  {
    id: 'msg_009',
    platform: 'discord',
    source_id: 'src_dc_01',
    channel_name: 'DevIndia #general-chat',
    sender_id: 'dc_user_5510',
    sender_name: 'CodeNewbie',
    text: 'omg I am literally dead laughing at this stackoverflow answer lmao, someone revive me',
    normalized_text: 'omg I am literally dead laughing at this stackoverflow answer lmao, someone revive me',
    language: 'English',
    timestamp: '2026-10-31T09:40:00Z',
    context: [
      'Pooja: Look at this regex someone wrote to validate an email address.',
      'Alok: It has 400 nested parentheses haha.',
      'CodeNewbie: The comment says "do not touch this or the building collapses".'
    ],
    category: 'Threat',
    severity: 'low',
    explanation: 'FALSE POSITIVE: Common internet idiom "dead laughing" expresses extreme amusement, with zero threatening intent.',
    target_user: null,
    status: 'dismissed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-31T10:05:00Z'
  },
  // Item 10: False Positive 3 (Technical system command)
  {
    id: 'msg_010',
    platform: 'discord',
    source_id: 'src_dc_01',
    channel_name: 'DevIndia #general-chat',
    sender_id: 'dc_user_8820',
    sender_name: 'LinuxSysAdmin',
    text: 'Just run pkill -9 to kill the rogue process immediately and purge the zombie workers from the host.',
    normalized_text: 'Just run pkill -9 to kill the rogue process immediately and purge the zombie workers from the host.',
    language: 'English',
    timestamp: '2026-10-31T08:12:00Z',
    context: [
      'Aditya: My node server is hanging on port 3000 and refusing new connections.',
      'Kunal: Check top or htop to see if cpu is pegged.',
      'Aditya: It won’t respond to SIGTERM.'
    ],
    category: 'Threat',
    severity: 'low',
    explanation: 'FALSE POSITIVE: Technical UNIX process management terminology ("kill the rogue process", "zombie workers").',
    target_user: null,
    status: 'dismissed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-31T08:45:00Z'
  },
  // Item 11: Hate Speech against community
  {
    id: 'msg_011',
    platform: 'telegram',
    source_id: 'src_tg_01',
    channel_name: 'Delhi University Student Forum',
    sender_id: 'tg_user_3819',
    sender_name: 'DeshPremi24',
    text: 'ye sab ek particular community ke log hi gundagardi karte hain, inko desh se bahar phenko k*tte.',
    normalized_text: 'yeh sab ek particular community ke log hi gundagardi karte hain, inko desh se bahar phenko kutte.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-31T07:30:00Z',
    context: [
      'Moderator: Keep discussions focused on hostel mess menu issues.',
      'Siddharth: Some altercation happened near gate 3 yesterday evening.',
      'Moderator: Local police handled it, please avoid spreading unverified rumors.'
    ],
    category: 'Hate speech',
    severity: 'high',
    explanation: 'Communal hate speech and xenophobic dehumanization advocating unlawful expulsion and calling community "k*tte".',
    target_user: null,
    status: 'escalated',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-31T08:00:00Z'
  },
  // Item 12: Sexual Harassment on Discord
  {
    id: 'msg_012',
    platform: 'discord',
    source_id: 'src_dc_02',
    channel_name: 'Campus Tech Hub #voice-text',
    sender_id: 'dc_user_9901',
    sender_name: 'ShadowStalker',
    text: 'send me your private pics on snapchat or I will leak your phone number on this group @priya_sharma_du.',
    normalized_text: 'Send me your private pictures on Snapchat or I will leak your phone number on this group @priya_sharma_du.',
    language: 'English',
    timestamp: '2026-10-31T06:50:00Z',
    context: [
      'Priya Sharma: Please register for the hackathon mentorship session.',
      'ShadowStalker: Check your DMs priya.',
      'Priya Sharma: I only communicate through official channels.'
    ],
    category: 'Sexual content',
    severity: 'high',
    explanation: 'Extortion involving sexual content solicitation and non-consensual personal information disclosure threat (doxxing).',
    target_user: '@priya_sharma_du',
    status: 'escalated',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-31T07:10:00Z'
  },
  // Item 13: Bullying / Insult in Hinglish
  {
    id: 'msg_013',
    platform: 'telegram',
    source_id: 'src_tg_01',
    channel_name: 'Delhi University Student Forum',
    sender_id: 'tg_user_1102',
    sender_name: 'Vikky_Boi',
    text: 'abe chirkut chup baith, dimag me bhusa bhara hai tere. tu bas chamchagiri kar sakta hai.',
    normalized_text: 'abey chirkut chup baith, dimaag mein bhoosa bhara hai tere. tu bas chamchagiri kar sakta hai.',
    language: 'Hinglish',
    timestamp: '2026-10-31T05:45:00Z',
    context: [
      'Manish: Library timing extension notice has been displayed.',
      'Nitin: Who even asked for 11 PM? 9 PM was enough.',
      'Manish: Many day-scholars study till late during exams.'
    ],
    category: 'Insult/Bullying',
    severity: 'medium',
    explanation: 'Demeaning and contemptuous personal insults ("chirkut", "dimag me bhusa", "chamchagiri").',
    target_user: null,
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-31T06:15:00Z'
  },
  // Item 14: Threat on YouTube
  {
    id: 'msg_014',
    platform: 'youtube',
    source_id: 'src_yt_01',
    channel_name: 'Campus Spotlight & Debates',
    sender_id: 'yt_user_7731',
    sender_name: 'DesiRage99',
    text: 'iss speaker ko thappad marne ka mann kar raha hai. kash mai waha hota to batata isko.',
    normalized_text: 'iss speaker ko thappad maarne ka mann kar raha hai. kaash main wahan hota toh batata isko.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-30T22:15:00Z',
    context: [
      'Campus Spotlight: Round 2 debate on student welfare budgets.',
      'User101: Interesting arguments regarding sports facilities.',
      'Kavita: The speaker addressed every question patiently.'
    ],
    category: 'Threat',
    severity: 'medium',
    explanation: 'Expression of physical aggression and intent to commit battery ("thappad marne ka mann kar raha hai").',
    target_user: null,
    status: 'new'
  },
  // Item 15: Repeat Target @arjun_v98 on Discord
  {
    id: 'msg_015',
    platform: 'discord',
    source_id: 'src_dc_01',
    channel_name: 'DevIndia #general-chat',
    sender_id: 'dc_user_2234',
    sender_name: 'TrollMaster9',
    text: '@arjun_v98 tu coding chhod ke bhik mangna shuru kar, tera dimaag ghutne me hai idiot loser.',
    normalized_text: '@arjun_v98 tu coding chhod kar bheekh maangna shuru kar, tera dimaag ghutne mein hai idiot loser.',
    language: 'Hinglish',
    timestamp: '2026-10-30T20:30:00Z',
    context: [
      'Arjun Verma: Hey guys, getting a TypeError on my Redux dispatch in line 44.',
      'Dev1: Check if the action creator is returning a plain object or thunk.',
      'Arjun Verma: Oh wait, missed importing the async thunk handler.'
    ],
    category: 'Insult/Bullying',
    severity: 'medium',
    explanation: 'Hostile personal put-downs and humiliation targeted at user learning in community channel.',
    target_user: '@arjun_v98',
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-30T21:00:00Z'
  },
  // Item 16: Repeat target @rohit_tech_lead on Discord
  {
    id: 'msg_016',
    platform: 'discord',
    source_id: 'src_dc_01',
    channel_name: 'DevIndia #general-chat',
    sender_id: 'dc_user_6654',
    sender_name: 'ToxicSniper',
    text: '@rohit_tech_lead is an arrogant piece of garbage. lets spam every repo this clown owns until he resigns.',
    normalized_text: '@rohit_tech_lead is an arrogant piece of garbage. lets spam every repo this clown owns until he resigns.',
    language: 'English',
    timestamp: '2026-10-30T19:12:00Z',
    context: [
      'DevHub: Release v2.4.0 is tagged and changelog published.',
      'Mohit: Great job on the query latency improvements.',
      'ToxicSniper: Who asked for these features? Waste of maintainer time.'
    ],
    category: 'Harassment',
    severity: 'high',
    explanation: 'Targeted character assassination and call for coordinated brigading/spamming across user repositories.',
    target_user: '@rohit_tech_lead',
    status: 'new'
  },
  // Item 17: Punjabi verbal assault on YouTube
  {
    id: 'msg_017',
    platform: 'youtube',
    source_id: 'src_yt_01',
    channel_name: 'Campus Spotlight & Debates',
    sender_id: 'yt_user_8829',
    sender_name: 'Sher_Punjab_01',
    text: 'bakwaas band kar oye k*tteya, chup chaap beh ja nai te chittar khaenga.',
    normalized_text: 'bakwaas band kar oye kutteya, chup chaap beh ja nahi te chittar khaayenga.',
    language: 'Punjabi (Romanized)',
    timestamp: '2026-10-30T18:00:00Z',
    context: [
      'Campus Spotlight: Discussion on agricultural technology innovations.',
      'Harpreet: Good points raised about drip irrigation subsidies.',
      'Aman: Farmers need more direct technical awareness.'
    ],
    category: 'Insult/Bullying',
    severity: 'medium',
    explanation: 'Verbal aggression in Romanized Punjabi with physical thrashing threat ("chittar khaenga" - will get beaten with slippers) and slur.',
    target_user: null,
    status: 'new'
  },
  // Item 18: Threat / Bullying on Telegram
  {
    id: 'msg_018',
    platform: 'telegram',
    source_id: 'src_tg_01',
    channel_name: 'Delhi University Student Forum',
    sender_id: 'tg_user_9918',
    sender_name: 'RuffianBoy',
    text: 'teri gadi ka number note kar liya hai, metro station ke bahar gher lenge tujhe saale.',
    normalized_text: 'teri gaadi ka number note kar liya hai, metro station ke bahar gher lenge tujhe saale.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-30T16:20:00Z',
    context: [
      'Saurabh: Parking space in front of Arts Faculty is packed today.',
      'Vivek: Yeah took 20 mins to find a slot.',
      'Saurabh: Some guy blocked my bike and started arguing aggressively.'
    ],
    category: 'Threat',
    severity: 'high',
    explanation: 'Stalking and mob intimidation threat targeting individual vehicle and transit point ("metro station ke bahar gher lenge").',
    target_user: null,
    status: 'new'
  },
  // Item 19: Repeat Target @arjun_v98 on Telegram
  {
    id: 'msg_019',
    platform: 'telegram',
    source_id: 'src_tg_02',
    channel_name: 'OpenSource Bharat Community',
    sender_id: 'tg_user_4431',
    sender_name: 'DarkCoder',
    text: '@arjun_v98 tu bas bhonkta rehta hai group me, chup kar varna admin se ban karwa ke tere bare me post daalunga.',
    normalized_text: '@arjun_v98 tu bas bhonkta rehta hai group mein, chup kar warna admin se ban karwa ke tere baare mein post daaloonga.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-30T15:10:00Z',
    context: [
      'Arjun Verma: Hey team, please remember to update the sprint tasks.',
      'DarkCoder: Nobody asked for your reminder.',
      'Arjun Verma: It was agreed in the team standup yesterday.'
    ],
    category: 'Harassment',
    severity: 'medium',
    explanation: 'Targeted silencing and intimidation threat ("tu bas bhonkta rehta hai", smear campaign warning).',
    target_user: '@arjun_v98',
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-30T15:45:00Z'
  },
  // Item 20: Repeat target @rohit_tech_lead on YouTube
  {
    id: 'msg_020',
    platform: 'youtube',
    source_id: 'src_yt_02',
    channel_name: 'TechBytes Hindi Tutorials',
    sender_id: 'yt_user_4412',
    sender_name: 'HaterTech',
    text: '@rohit_tech_lead teach mat kar fraud aadmi. You stole code from github and made this tutorial you scumbag.',
    normalized_text: '@rohit_tech_lead teach mat kar fraud aadmi. You stole code from github and made this tutorial you scumbag.',
    language: 'Hinglish',
    timestamp: '2026-10-30T14:05:00Z',
    context: [
      'TechBytes Hindi: Building a FastAPI backend from scratch tutorial.',
      'Learner1: Very clear explanation of dependencies.',
      'Prakash: Helped me fix my database connection issue.'
    ],
    category: 'Insult/Bullying',
    severity: 'medium',
    explanation: 'Defamatory personal attack and abusive labeling ("fraud aadmi", "scumbag") targeting creator.',
    target_user: '@rohit_tech_lead',
    status: 'new'
  },
  // Item 21: False Positive 4 (Pagal in affectionate banter)
  {
    id: 'msg_021',
    platform: 'telegram',
    source_id: 'src_tg_01',
    channel_name: 'Delhi University Student Forum',
    sender_id: 'tg_user_6672',
    sender_name: 'Sneha_K',
    text: 'tu bilkul pagal hai yaar itna mast surprise birthday cake kon leke aata hai class me love you guys',
    normalized_text: 'tu bilkul pagal hai yaar itna mast surprise birthday cake kaun leke aata hai class mein love you guys',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-30T12:00:00Z',
    context: [
      'Varun: Happy birthday Sneha!! Hope you liked the celebration.',
      'Riya: Best day ever, the chocolate truffle was amazing.',
      'Sneha_K: Seriously did not expect you all to coordinate with the teacher!'
    ],
    category: 'Insult/Bullying',
    severity: 'low',
    explanation: 'FALSE POSITIVE: Affectionate friendly banter using "pagal" (crazy) in a celebratory birthday surprise context.',
    target_user: null,
    status: 'dismissed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-30T12:20:00Z'
  },
  // Item 22: Hate speech / Xenophobic on Telegram
  {
    id: 'msg_022',
    platform: 'telegram',
    source_id: 'src_tg_01',
    channel_name: 'Delhi University Student Forum',
    sender_id: 'tg_user_5501',
    sender_name: 'NationalistVoice',
    text: 'North East ke students ko yaha rehne ka adhikar nahi hai, wapas jao apne ilaqe me.',
    normalized_text: 'North East ke students ko yahan rehne ka adhikaar nahi hai, wapas jao apne ilaaqe mein.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-30T11:15:00Z',
    context: [
      'Forum Admin: Annual North East Cultural Festival announced for next week.',
      'Tenzin: Everyone is invited, traditional folk dance and food stalls will be there.',
      'Anjali: Looking forward to the bamboo dance performance!'
    ],
    category: 'Hate speech',
    severity: 'high',
    explanation: 'Regionalist xenophobia and discriminatory hate speech targeting North East Indian students.',
    target_user: null,
    status: 'escalated',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-30T11:40:00Z'
  },
  // Item 23: Discord harassment with obfuscated words
  {
    id: 'msg_023',
    platform: 'discord',
    source_id: 'src_dc_02',
    channel_name: 'Campus Tech Hub #voice-text',
    sender_id: 'dc_user_3389',
    sender_name: 'AnonGamer',
    text: 'chup kar bsdk teri aukaat nahi hai voice channel pe aane ki. bhag ja yaha se k*tte.',
    normalized_text: 'chup kar bhosdi** teri aukaat nahi hai voice channel pe aane ki. bhaag ja yahan se kutte.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-30T09:30:00Z',
    context: [
      'Gaurav: Hey anyone want to team up for Valorant competitive?',
      'AnonGamer: Who invited this noob?',
      'Gaurav: Just playing casual comp bro, no need to be rude.'
    ],
    category: 'Insult/Bullying',
    severity: 'high',
    explanation: 'Abusive profane insults ("bsdk", "aukaat nahi hai", "k*tte") aimed at silencing and gatekeeping.',
    target_user: null,
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-30T10:00:00Z'
  },
  // Item 24: Threat on Telegram
  {
    id: 'msg_024',
    platform: 'telegram',
    source_id: 'src_tg_02',
    channel_name: 'OpenSource Bharat Community',
    sender_id: 'tg_user_8871',
    sender_name: 'RageKing',
    text: 'agar tune dubara meri post delete ki to tere ghar ka electricity connection katwa dunga aur danda bajega.',
    normalized_text: 'agar tune dobaara meri post delete ki toh tere ghar ka electricity connection katwa doonga aur danda bajega.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-29T21:40:00Z',
    context: [
      'Admin: Spam links promoting crypto schemes will be removed automatically.',
      'RageKing: It was a legitimate web3 airdrop announcement!',
      'Admin: Commercial promos are strictly prohibited under rule #4.'
    ],
    category: 'Threat',
    severity: 'medium',
    explanation: 'Retaliatory threat of utility disruption and physical violence against channel moderator.',
    target_user: null,
    status: 'new'
  },
  // Item 25: Sexual harassment on YouTube comments
  {
    id: 'msg_025',
    platform: 'youtube',
    source_id: 'src_yt_01',
    channel_name: 'Campus Spotlight & Debates',
    sender_id: 'yt_user_9941',
    sender_name: 'DesiRomeo_69',
    text: 'kya figure hai maam ka, ek raat ka kitna logi? drop your contact number babe.',
    normalized_text: 'kya figure hai maam ka, ek raat ka kitna logi? drop your contact number babe.',
    language: 'Hinglish',
    timestamp: '2026-10-29T19:25:00Z',
    context: [
      'Campus Spotlight: Professor Neha speaks on Women in STEM leadership.',
      'Ritika: Very inspiring talk on overcoming institutional barriers.',
      'Sunil: Great initiatives taken by the university physics department.'
    ],
    category: 'Sexual content',
    severity: 'high',
    explanation: 'Gross sexual objectification, solicitation, and harassment directed at university lecturer.',
    target_user: null,
    status: 'escalated',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-29T20:00:00Z'
  },
  // Item 26: Repeat Target @priya_sharma_du on Discord
  {
    id: 'msg_026',
    platform: 'discord',
    source_id: 'src_dc_02',
    channel_name: 'Campus Tech Hub #voice-text',
    sender_id: 'dc_user_1177',
    sender_name: 'ToxicSniper',
    text: '@priya_sharma_du you are pathetic. nobody in this college respects you or your corrupt committee.',
    normalized_text: '@priya_sharma_du you are pathetic. nobody in this college respects you or your corrupt committee.',
    language: 'English',
    timestamp: '2026-10-29T18:10:00Z',
    context: [
      'Priya Sharma: We have set up anonymous feedback boxes in every department.',
      'ViperSquad: All for publicity stunts.',
      'Priya Sharma: The feedback directly goes to the ombudsman.'
    ],
    category: 'Harassment',
    severity: 'medium',
    explanation: 'Systematic disparagement and hostile targeted bullying in recurring pile-on against student representative.',
    target_user: '@priya_sharma_du',
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-29T18:50:00Z'
  },
  // Item 27: Bullying in Romanized Punjabi
  {
    id: 'msg_027',
    platform: 'telegram',
    source_id: 'src_tg_01',
    channel_name: 'Delhi University Student Forum',
    sender_id: 'tg_user_7716',
    sender_name: 'JattBoy_007',
    text: 'oye chawal bande, tu sanu sikhayenga? teri shakal k*tte wargi ae.',
    normalized_text: 'oye chawal bande, tu saanu sikhayenga? teri shakal kutte wargi hai.',
    language: 'Punjabi (Romanized)',
    timestamp: '2026-10-29T16:05:00Z',
    context: [
      'Gagandeep: Guys please maintain discipline during the union meeting.',
      'JattBoy_007: Who appointed you the referee?',
      'Gagandeep: Just requesting everyone so we can finish early.'
    ],
    category: 'Insult/Bullying',
    severity: 'low',
    explanation: 'Dehumanizing verbal insult comparing appearance to an animal in Romanized Punjabi.',
    target_user: null,
    status: 'new'
  },
  // Item 28: Repeat target @rohit_tech_lead on Telegram
  {
    id: 'msg_028',
    platform: 'telegram',
    source_id: 'src_tg_02',
    channel_name: 'OpenSource Bharat Community',
    sender_id: 'tg_user_4490',
    sender_name: 'ScriptKiddie99',
    text: '@rohit_tech_lead your code is trash, you are trash, get out of our community before we dox your linkedin and get you fired.',
    normalized_text: '@rohit_tech_lead your code is trash, you are trash, get out of our community before we dox your linkedin and get you fired.',
    language: 'English',
    timestamp: '2026-10-29T14:30:00Z',
    context: [
      'Rohit V: Released v1.2 with security patches. Please upgrade dependencies.',
      'Karthik: Appreciate the fast turnaround on the CVE.',
      'ScriptKiddie99: You broke backwards compatibility in the auth module!'
    ],
    category: 'Harassment',
    severity: 'high',
    explanation: 'Blackmail, livelihood threat, and targeted harassment attempting to force resignation through doxxing.',
    target_user: '@rohit_tech_lead',
    status: 'new'
  },
  // Item 29: Insult / Cyber-bullying on YouTube
  {
    id: 'msg_029',
    platform: 'youtube',
    source_id: 'src_yt_02',
    channel_name: 'TechBytes Hindi Tutorials',
    sender_id: 'yt_user_3381',
    sender_name: 'RoastKing_2026',
    text: 'itna ghatiya sound quality aur sardi jaisi awaz, pehle mic kharid bhikari fir video bana.',
    normalized_text: 'itna ghatiya sound quality aur sardi jaisi aawaaz, pehle mic khareed bhikaari phir video bana.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-29T12:10:00Z',
    context: [
      'TechBytes Hindi: Beginners guide to CSS grid and flexbox.',
      'StudentA: Thanks sir, clear breakdown.',
      'Pooja: Audio has a bit of background hiss but content is helpful.'
    ],
    category: 'Insult/Bullying',
    severity: 'low',
    explanation: 'Classist slurs ("bhikari") and hostile disparagement of content creator.',
    target_user: null,
    status: 'new'
  },
  // Item 30: Threat on Discord
  {
    id: 'msg_030',
    platform: 'discord',
    source_id: 'src_dc_01',
    channel_name: 'DevIndia #general-chat',
    sender_id: 'dc_user_9923',
    sender_name: 'RageCoder',
    text: 'saale ko sabak sikhana padega, offline meetup me aao phir batata hu kaun kitna bada coder hai.',
    normalized_text: 'saale ko sabak sikhaana padega, offline meetup mein aao phir bataata hoon kaun kitna bada coder hai.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-29T10:15:00Z',
    context: [
      'Sameer: Tabs vs spaces debate is never ending lol.',
      'RageCoder: If you use 2 spaces in Python you deserve to get kicked out.',
      'Sameer: Chill man, it is personal preference.'
    ],
    category: 'Threat',
    severity: 'medium',
    explanation: 'Intimidation and threat of in-person confrontation at offline tech conference.',
    target_user: null,
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-29T11:00:00Z'
  },
  // Item 31: Repeat target @arjun_v98 on Discord
  {
    id: 'msg_031',
    platform: 'discord',
    source_id: 'src_dc_01',
    channel_name: 'DevIndia #general-chat',
    sender_id: 'dc_user_4491',
    sender_name: 'NullPointerX',
    text: '@arjun_v98 stop bootlicking the admins, tu unka chamcha hai aur hamesha rahega.',
    normalized_text: '@arjun_v98 stop bootlicking the admins, tu unka chamcha hai aur hamesha rahega.',
    language: 'Hinglish',
    timestamp: '2026-10-28T22:30:00Z',
    context: [
      'Admin: Server rules updated regarding promo links.',
      'Arjun Verma: Thanks for the clarification, helps keep the channel clean.',
      'NullPointerX: Look at him brown nosing.'
    ],
    category: 'Insult/Bullying',
    severity: 'low',
    explanation: 'Repeated disparagement and targeting of community contributor.',
    target_user: '@arjun_v98',
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-28T23:00:00Z'
  },
  // Item 32: Threat in Romanized Punjabi on Telegram
  {
    id: 'msg_032',
    platform: 'telegram',
    source_id: 'src_tg_01',
    channel_name: 'Delhi University Student Forum',
    sender_id: 'tg_user_6619',
    sender_name: 'SidhuFan_PB',
    text: 'teri himmat kiven hoyi eh kehn di? je tu pind val gaya taan zinda nahi mudega.',
    normalized_text: 'teri himmat kiven hoyi eh kehn di? je tu pind vall gaya taan zinda nahi mudega.',
    language: 'Punjabi (Romanized)',
    timestamp: '2026-10-28T20:15:00Z',
    context: [
      'Param: Rural agricultural subsidies need strict auditing.',
      'SidhuFan_PB: Don’t speak about matters you don’t understand city boy.',
      'Param: I am quoting the Comptroller Auditor General report.'
    ],
    category: 'Threat',
    severity: 'high',
    explanation: 'Death threat in Romanized Punjabi ("zinda nahi mudega" - will not return alive) over policy debate.',
    target_user: null,
    status: 'escalated',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-28T20:45:00Z'
  },
  // Item 33: Hate speech on YouTube
  {
    id: 'msg_033',
    platform: 'youtube',
    source_id: 'src_yt_01',
    channel_name: 'Campus Spotlight & Debates',
    sender_id: 'yt_user_5521',
    sender_name: 'CasteAware_99',
    text: 'quota wale students merit barbad karte hain, inko padhai ka haq nahi hai bhagao yaha se.',
    normalized_text: 'quota waale students merit barbaad karte hain, inko padhai ka haq nahi hai bhagao yahan se.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-28T18:00:00Z',
    context: [
      'Campus Spotlight: Discussion on affirmative action and hostel room allocations.',
      'StudentUnion: Reservation policies are constitutionally mandated.',
      'ProfSharma: We must ensure access to education for underprivileged communities.'
    ],
    category: 'Hate speech',
    severity: 'high',
    explanation: 'Caste-based hate speech and discriminatory rhetoric denying constitutional right to education.',
    target_user: null,
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-28T18:30:00Z'
  },
  // Item 34: Insult on Discord
  {
    id: 'msg_034',
    platform: 'discord',
    source_id: 'src_dc_02',
    channel_name: 'Campus Tech Hub #voice-text',
    sender_id: 'dc_user_7733',
    sender_name: 'GamerKid2',
    text: 'shut your dumb mouth, you sound like a dying rat. nobody wants your garbage opinion here.',
    normalized_text: 'Shut your dumb mouth, you sound like a dying rat. Nobody wants your garbage opinion here.',
    language: 'English',
    timestamp: '2026-10-28T16:20:00Z',
    context: [
      'Kritika: Can we turn down the in-game music in the voice channel?',
      'Kritika: It is difficult to hear game callouts.',
      'Sam: Yeah bot volume is at 100% currently.'
    ],
    category: 'Insult/Bullying',
    severity: 'medium',
    explanation: 'Aggressive verbal abuse and silencing behavior in voice channel chat.',
    target_user: null,
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-28T17:00:00Z'
  },
  // Item 35: Cyber-bullying on Telegram
  {
    id: 'msg_035',
    platform: 'telegram',
    source_id: 'src_tg_02',
    channel_name: 'OpenSource Bharat Community',
    sender_id: 'tg_user_3311',
    sender_name: 'TechRebel',
    text: 'tera resume dekh ke interviewers hase honge. incompetent moron, don’t ever write code again.',
    normalized_text: 'tera resume dekh kar interviewers hanse honge. incompetent moron, don’t ever write code again.',
    language: 'Hinglish',
    timestamp: '2026-10-28T14:45:00Z',
    context: [
      'Ayush: Received rejection from internship after 3 rounds, feeling a bit demotivated.',
      'Saurabh: Don’t worry Ayush, market is tough right now, keep building.',
      'Megha: Share your resume anonymously in #resume-review, we can give feedback.'
    ],
    category: 'Insult/Bullying',
    severity: 'medium',
    explanation: 'Cruel malicious ridicule targeting vulnerable job-seeking student ("incompetent moron").',
    target_user: null,
    status: 'new'
  },
  // Item 36: Threat / Obfuscated swear on YouTube
  {
    id: 'msg_036',
    platform: 'youtube',
    source_id: 'src_yt_02',
    channel_name: 'TechBytes Hindi Tutorials',
    sender_id: 'yt_user_1143',
    sender_name: 'ToxicDude_01',
    text: 'tere channel ko mass report karke strike dilwaunga bsdk, dekhna tera pura channel delete hoga.',
    normalized_text: 'tere channel ko mass report karke strike dilwaunga bhosd***, dekhna tera poora channel delete hoga.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-28T11:30:00Z',
    context: [
      'TechBytes Hindi: Explaining copyright and fair use guidelines for tech YouTubers.',
      'CreatorA: Very helpful breakdown of DMCA counter-notices.',
      'TechBytes Hindi: Always ensure you transform original work significantly.'
    ],
    category: 'Harassment',
    severity: 'medium',
    explanation: 'Malicious mass-reporting threat with vulgar profanity aimed at economic sabotage of creator.',
    target_user: null,
    status: 'new'
  },
  // Item 37: Harassment on Discord
  {
    id: 'msg_037',
    platform: 'discord',
    source_id: 'src_dc_01',
    channel_name: 'DevIndia #general-chat',
    sender_id: 'dc_user_8832',
    sender_name: 'EliteHackerX',
    text: 'I know what school your sister goes to. stop reporting my accounts or I will post her pics.',
    normalized_text: 'I know what school your sister goes to. Stop reporting my accounts or I will post her pictures.',
    language: 'English',
    timestamp: '2026-10-28T09:15:00Z',
    context: [
      'Moderator: User was warned twice for crypto scam DMing.',
      'EliteHackerX: Unban my main account immediately.',
      'Moderator: Bans for predatory behavior are non-negotiable.'
    ],
    category: 'Threat',
    severity: 'high',
    explanation: 'Severe criminal blackmail threatening safety and privacy of moderator’s family member.',
    target_user: null,
    status: 'escalated',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-28T09:30:00Z'
  },
  // Item 38: Insult in Romanized Punjabi on YouTube
  {
    id: 'msg_038',
    platform: 'youtube',
    source_id: 'src_yt_01',
    channel_name: 'Campus Spotlight & Debates',
    sender_id: 'yt_user_7729',
    sender_name: 'PB_Rider',
    text: 'ehna nu koi bolan di tameez sikhao, k*njaro wangu ladi jande ne.',
    normalized_text: 'ehna nu koi bolan di tameez sikhao, kanjaron wangu ladi jaande ne.',
    language: 'Punjabi (Romanized)',
    timestamp: '2026-10-27T23:10:00Z',
    context: [
      'Campus Spotlight: Cross-college quiz competition highlights.',
      'TeamA: Great buzzer round by both sides.',
      'TeamB: Very close finish in the science category.'
    ],
    category: 'Insult/Bullying',
    severity: 'low',
    explanation: 'Derogatory communal caste slur ("k*njaro wangu") used to demean debate participants.',
    target_user: null,
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-28T00:15:00Z'
  },
  // Item 39: Sexual harassment on Telegram
  {
    id: 'msg_039',
    platform: 'telegram',
    source_id: 'src_tg_01',
    channel_name: 'Delhi University Student Forum',
    sender_id: 'tg_user_9981',
    sender_name: 'CreepAccount2',
    text: 'kisi ladki ko sex chat karni hai to DM karo, will pay 5000 rs per hour. no timewasters.',
    normalized_text: 'kisi ladki ko sex chat karni hai toh DM karo, will pay 5000 rs per hour. no timewasters.',
    language: 'Hinglish',
    timestamp: '2026-10-27T20:50:00Z',
    context: [
      'Student: Anyone has lecture notes for corporate accounting unit 3?',
      'Pooja: I have uploaded scanned PDFs to the shared Google Drive folder.',
      'Student: Thank you so much Pooja!'
    ],
    category: 'Sexual content',
    severity: 'high',
    explanation: 'Unsolicited sexual solicitation and commercial exploitation pitch in student academic channel.',
    target_user: null,
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-27T21:10:00Z'
  },
  // Item 40: Hate speech on Discord
  {
    id: 'msg_040',
    platform: 'discord',
    source_id: 'src_dc_02',
    channel_name: 'Campus Tech Hub #voice-text',
    sender_id: 'dc_user_5541',
    sender_name: 'DarkLord99',
    text: 'all feminists are cancer to society. they should be stripped of voting rights and locked in kitchens.',
    normalized_text: 'All feminists are cancer to society. They should be stripped of voting rights and locked in kitchens.',
    language: 'English',
    timestamp: '2026-10-27T18:40:00Z',
    context: [
      'Campus Club: Panel discussion on gender diversity in engineering startups.',
      'Aditi: Happy to see 40% participation from women founders this year.',
      'Karan: Great startup pitches overall.'
    ],
    category: 'Hate speech',
    severity: 'high',
    explanation: 'Misogynistic hate speech advocating stripping of legal constitutional rights.',
    target_user: null,
    status: 'new'
  },
  // Item 41: Threat on Telegram
  {
    id: 'msg_041',
    platform: 'telegram',
    source_id: 'src_tg_01',
    channel_name: 'Delhi University Student Forum',
    sender_id: 'tg_user_1239',
    sender_name: 'BulletRaja',
    text: 'tu road pe mil phir batata hu kaun kiska baap hai. chaku se goud dunga samjha?',
    normalized_text: 'tu road pe mil phir bataata hoon kaun kiska baap hai. chaaku se goud doonga samjha?',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-27T16:15:00Z',
    context: [
      'Raghav: Please don’t park bikes haphazardly blocking the hostel gate.',
      'BulletRaja: Mai jaha marzi park karu, tu kaun hota hai rokne wala?',
      'Raghav: Ambulance and fire safety vehicle clearance is required.'
    ],
    category: 'Threat',
    severity: 'high',
    explanation: 'Direct lethal weapon threat ("chaku se goud dunga" - will stab with knife) following parking dispute.',
    target_user: null,
    status: 'new'
  },
  // Item 42: Bullying on YouTube
  {
    id: 'msg_042',
    platform: 'youtube',
    source_id: 'src_yt_01',
    channel_name: 'Campus Spotlight & Debates',
    sender_id: 'yt_user_3389',
    sender_name: 'TrollBot99',
    text: 'ye speaker to ekdum chomu lagta hai. aisi shakal leke camera ke samne kaise aa jate hain log.',
    normalized_text: 'yeh speaker toh ekdum chomu lagta hai. aisi shakal leke camera ke saamne kaise aa jaate hain log.',
    language: 'Hindi (Romanized)',
    timestamp: '2026-10-27T14:20:00Z',
    context: [
      'Campus Spotlight: Environmental science student presents research on yamuna cleanup.',
      'Anita: Very good empirical data presented.',
      'Suresh: Appreciate the field survey methodology.'
    ],
    category: 'Insult/Bullying',
    severity: 'low',
    explanation: 'Superficial derogatory appearance shaming ("chomu", "aisi shakal").',
    target_user: null,
    status: 'dismissed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-27T15:00:00Z'
  },
  // Item 43: Discord harassment with obfuscation
  {
    id: 'msg_043',
    platform: 'discord',
    source_id: 'src_dc_01',
    channel_name: 'DevIndia #general-chat',
    sender_id: 'dc_user_7718',
    sender_name: 'AnonymousDev',
    text: 'tera code dekh ke ulti aati hai b@stard. tu computer science ka sabse bada kalank hai.',
    normalized_text: 'tera code dekh kar ulti aati hai bastard. tu computer science ka sabse bada kalank hai.',
    language: 'Hinglish',
    timestamp: '2026-10-27T11:45:00Z',
    context: [
      'Harsh: Finally merged my first PR to the documentation repo!',
      'Alok: Congratulations Harsh, keep contributing.',
      'Sneha: Nice first step into open source.'
    ],
    category: 'Insult/Bullying',
    severity: 'medium',
    explanation: 'Hostile gatekeeping, abusive insult ("b@stard"), and public shaming of novice contributor.',
    target_user: null,
    status: 'new'
  },
  // Item 44: Sexual harassment on Discord
  {
    id: 'msg_044',
    platform: 'discord',
    source_id: 'src_dc_02',
    channel_name: 'Campus Tech Hub #voice-text',
    sender_id: 'dc_user_6610',
    sender_name: 'NightHawk',
    text: 'hey baby join the private voice channel alone, I want to hear your voice in the dark.',
    normalized_text: 'Hey baby join the private voice channel alone, I want to hear your voice in the dark.',
    language: 'English',
    timestamp: '2026-10-27T08:30:00Z',
    context: [
      'Kavya: Is the study group starting at 9 PM or 9:30 PM?',
      'Rohan: Starting at 9:30 PM once everyone joins.',
      'Kavya: Okay see you all in the general study room.'
    ],
    category: 'Sexual content',
    severity: 'medium',
    explanation: 'Unsolicited predatory suggestive advances targeting female participant in student Discord server.',
    target_user: null,
    status: 'reviewed',
    reviewed_by: 'moderator@vaani.org',
    reviewed_at: '2026-10-27T09:15:00Z'
  },
  // Item 45: Threat / Cyberbullying in Punjabi Romanized
  {
    id: 'msg_045',
    platform: 'telegram',
    source_id: 'src_tg_02',
    channel_name: 'OpenSource Bharat Community',
    sender_id: 'tg_user_9912',
    sender_name: 'KisanPower',
    text: 'je tu dubara eh bakwaas boli, taan tere muh te chaped maaran aawanga.',
    normalized_text: 'je tu dobaara eh bakwaas boli, taan tere munh te chapped maaran aavanga.',
    language: 'Punjabi (Romanized)',
    timestamp: '2026-10-26T21:00:00Z',
    context: [
      'Mandeep: Let’s keep discussion related to agricultural sensor hardware.',
      'Ravi: Software optimization for low-power solar relays is also relevant.',
      'Mandeep: Agreed, both hardware and firmware are important.'
    ],
    category: 'Threat',
    severity: 'medium',
    explanation: 'Physical violence threat in Romanized Punjabi ("chaped maaran aawanga" - will come to slap your face).',
    target_user: null,
    status: 'new'
  }
];

export const INITIAL_OVERVIEW_STATS: OverviewStats = {
  messages_scanned: 18450,
  messages_flagged: 45,
  high_severity_open: 11,
  avg_review_time_mins: 4.8,
  flags_over_time: [
    { date: 'Oct 25', flags: 4, high: 1, medium: 2, low: 1 },
    { date: 'Oct 26', flags: 6, high: 2, medium: 3, low: 1 },
    { date: 'Oct 27', flags: 8, high: 3, medium: 3, low: 2 },
    { date: 'Oct 28', flags: 9, high: 2, medium: 5, low: 2 },
    { date: 'Oct 29', flags: 7, high: 3, medium: 3, low: 1 },
    { date: 'Oct 30', flags: 11, high: 5, medium: 4, low: 2 },
    { date: 'Oct 31', flags: 12, high: 6, medium: 4, low: 2 },
  ],
  flags_by_category: [
    { category: 'Insult/Bullying', count: 16 },
    { category: 'Threat', count: 11 },
    { category: 'Harassment', count: 9 },
    { category: 'Hate speech', count: 5 },
    { category: 'Sexual content', count: 4 },
  ],
  flags_by_language: [
    { language: 'Hindi (Romanized)', count: 18 },
    { language: 'English', count: 12 },
    { language: 'Hinglish', count: 9 },
    { language: 'Punjabi (Romanized)', count: 6 },
  ],
  flags_by_platform: [
    { platform: 'telegram', count: 19 },
    { platform: 'discord', count: 16 },
    { platform: 'youtube', count: 10 },
  ],
};

export const INITIAL_SETTINGS: SystemSettings = {
  instant_high_severity: true,
  daily_digest_low: true,
  telegram_bot_token: '7192837461:AAFk9102834710928347',
  telegram_chat_id: '984729182',
  monitored_languages: [
    'Hindi (Romanized)',
    'Hinglish',
    'Punjabi (Romanized)',
    'English'
  ],
  mock_mode: true,
};
